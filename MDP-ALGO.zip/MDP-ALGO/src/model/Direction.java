package model;

public enum Direction {
	North,South,East, West,
	LEFT,RIGHT,
	FRONT,BACK;
}
